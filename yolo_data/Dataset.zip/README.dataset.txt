# breed > 2023-01-19 4:15pm
https://universe.roboflow.com/satish-kumar-mishra-mmpke/breed-ss8yg

Provided by a Roboflow user
License: CC BY 4.0

